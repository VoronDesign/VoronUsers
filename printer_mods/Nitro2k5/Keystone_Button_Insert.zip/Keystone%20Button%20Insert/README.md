# Keystone Button Insert

Simple Keystone button insert for round 16mm switches.<br>

![CAD_Skirt](Images/Keystone_Skirt.PNG)
<br><br>

# File

|[a]_keystone_button_insert_16mm.stl|
|:---:|
|![CAD_Image](Images/Keystone_Insert.PNG)|
<br>


# Compatibility

|V0|V1.8|V2.4|VSW|Trident|
|:---:|:---:|:---:|:---:|:---:|
| :x: | :heavy_check_mark: | :heavy_check_mark: | :x: | :heavy_check_mark: |

<br>

# Changelog
v1.0 (08.11.2022) - Release
<br>
