I'm still writing this doc. The files released early since a few people asked for stl files and I didn't want to keep them waiting.
Mod will be uploaded to VoronUsers github when documentation is finished.

You need 12 (350), 8 (300), 4 (250) 12*12mm 5mm tactile switches. Make sure they are through hole, not SMD!

    Amazon: https://amzn.to/3788dfZ
Aliexpress: https://s.click.aliexpress.com/e/_eKCJlo

Home button needs to be fixed, will be fixed on final release.

Icons used: https://www.iconfinder.com/iconsets/arrows-elements-outline

Wiring is easy to figure out but if you need a guide, wait for the final release.